import pygame
import math
import random
import os

pygame.init()

WIDTH = 1000
HEIGHT = 1000

XLEN = WIDTH/2
YLEN = HEIGHT/2

THIS_FILE = os.path.join(os.path.dirname(__file__), "Images")
print(THIS_FILE)
ICON_IMAGE = os.path.join(THIS_FILE, "icon.png")
print(ICON_IMAGE)
ICON = pygame.image.load(ICON_IMAGE)


screen = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption("Editor")
pygame.display.set_icon(ICON)

BG = (190,210,240)
BG_SEL = (220,230,255)
WHITE = (255,255,255)
BLACK = (0,0,0)

screen.fill(WHITE)
pygame.display.flip()

x_center = 0
y_center = 0

scale = 10

selected = 0

SIZES = [(2,2),(1,1),(1,1),(2,2),(1,2),(1,1)]

ELEMENT_COLORS = [(255,255,0),(0,0,0),(128,128,128),(0,0,50),(50,50,50),(0,0,75)]

BLOCK_RANGE = (0,3)
ENEMY_RANGE = (3,6)

elements = []

ZOOM_INCREMENT = math.pow(1.1,1/4)

show_grid = True

clock = pygame.time.Clock()


def Draw_grid():
    step = 1
    #step = 10*math.floor(math.log(math.ceil(1/scale),10) + 1)
    if scale > 30:
        step = math.floor(math.pow(4,math.floor(math.log(scale/8,4))))
    #X
    dx = x_center % step
    for pos in range(0,math.floor(scale)+2*step,step):
        x_pos = math.floor(XLEN*((pos-dx)/scale) + XLEN)
        pygame.draw.line(screen, BLACK, (x_pos, HEIGHT), (x_pos, 0))
    for pos in range(0,math.floor(scale)+2*step,step):
        x_pos = math.floor(XLEN*((-pos-dx)/scale) + XLEN)
        pygame.draw.line(screen, BLACK, (x_pos, HEIGHT), (x_pos, 0))
    pygame.draw.line(screen, BLACK, (math.floor(-x_center/scale*XLEN + XLEN), HEIGHT), (math.floor(-x_center/scale*XLEN + XLEN), 0), 3)
    
    #Y
    dy = y_center % step
    for pos in range(0,math.floor(scale)+2*step,step):
        y_pos = math.floor(YLEN*((pos-dy)/scale) + YLEN)
        pygame.draw.line(screen, BLACK, (WIDTH, y_pos), (0, y_pos))
    for pos in range(0,math.floor(scale)+2*step,step):
        y_pos = math.floor(YLEN*((-pos-dy)/scale) + YLEN)
        pygame.draw.line(screen, BLACK, (WIDTH, y_pos), (0, y_pos))
    pygame.draw.line(screen, BLACK, (WIDTH,math.floor(-y_center/scale*YLEN + YLEN)), (0,math.floor(-y_center/scale*YLEN + YLEN)), 3)

def Draw_screen():
    screen.fill(BG)
    if show_grid:
        Draw_grid()
    Color_square(Find_square(pygame.mouse.get_pos()),BG_SEL,0)
    for element in elements:
        Color_square((element[1][0], element[1][1]), ELEMENT_COLORS[element[0]],SIZES[element[0]])
    pygame.display.flip()

def Zoom_relative(new_scale,mouse_pos):
    global scale, x_center, y_center
    
    x_mouse_relative = mouse_pos[0]/ XLEN - 1
    y_mouse_relative = mouse_pos[1]/ YLEN - 1
    
    x_mouse_real = x_mouse_relative*scale + x_center
    y_mouse_real = y_mouse_relative*scale + y_center
    
    x_center = x_mouse_real - ((x_mouse_real - x_center)*new_scale/scale)
    y_center = y_mouse_real - ((y_mouse_real - y_center)*new_scale/scale)
    
    scale = new_scale

def Find_square(mouse_pos):
    real_pos = Get_real_pos(mouse_pos)
    x_mouse_real = real_pos[0]
    y_mouse_real = real_pos[1]
    return (x_mouse_real, y_mouse_real)

def Color_square(pos, color,size):
    x_pos, y_pos = pos[0], pos[1]
    
    x_mouse_proj = math.floor((((x_pos-x_center)*XLEN/scale) + 1)+XLEN)
    y_mouse_proj = math.floor((((y_pos-y_center)*YLEN/scale) + 1)+YLEN)
    if size == 0:
        pygame.draw.rect(screen, color, pygame.rect.Rect((x_mouse_proj,y_mouse_proj),(SIZES[selected][0]*math.floor(XLEN/scale-1),SIZES[selected][1]*math.floor(YLEN/scale-1))))
    else:
        pygame.draw.rect(screen, color, pygame.rect.Rect((x_mouse_proj,y_mouse_proj),(size[0]*math.floor(XLEN/scale-1),size[1]*math.floor(YLEN/scale-1))))
def Get_real_pos(mouse_pos):
    x_mouse_real = math.floor(scale*(mouse_pos[0]/XLEN - 1) + x_center)
    y_mouse_real = math.floor(scale*(mouse_pos[1]/YLEN - 1) + y_center)
    return (x_mouse_real, y_mouse_real)

def Make_element(element):
    real_pos = Get_real_pos(pygame.mouse.get_pos())
    x_mouse_real, y_mouse_real = real_pos[0], real_pos[1]

    new_element = (element, real_pos)
    if Test_safe(element, real_pos):
        elements.append(new_element)

def Test_safe(element, pos):
    xa0 = pos[0]
    xa1 = pos[0] + SIZES[element][0] - 1
    ya0 = pos[1]
    ya1 = pos[1] + SIZES[element][1] - 1
    for s_element in elements:
        pos = s_element[1]
        xb0 = pos[0]
        xb1 = pos[0] + SIZES[s_element[0]][0] - 1
        yb0 = pos[1]
        yb1 = pos[1] + SIZES[s_element[0]][1] - 1
        if ((xa0 <= xb1 and xa0 >= xb0) or (xa1 >= xb0 and xa1 <= xb1)) and ((ya0 >= yb0 and ya0 <= yb1) or (yb0 <= ya1 and ya1 <= yb1)):
            return False
    return True
        
zoom_next = 0

done = False
while not done:
    if zoom_next > 0:
        Zoom_relative(scale/ZOOM_INCREMENT, pygame.mouse.get_pos())
        zoom_next -= 1
    if zoom_next < 0:
        Zoom_relative(scale*ZOOM_INCREMENT, pygame.mouse.get_pos())
        zoom_next += 1
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_TAB:
                selected += 1
                if selected == 6:
                    selected = 0
                print(selected)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 4 and not zoom_next:
                Zoom_relative(scale/ZOOM_INCREMENT, pygame.mouse.get_pos())
                zoom_next = 2
            if event.button == 5 and not zoom_next:
                Zoom_relative(scale*ZOOM_INCREMENT, pygame.mouse.get_pos())
                zoom_next = -2
            elif event.button == 1:
                Make_element(selected)
    Draw_screen()
    clock.tick(80)
pygame.quit()
